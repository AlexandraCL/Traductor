# """Programa que permita traducir una palabra"""

# traducciones = {
#     'hola': 'hello',
#     'mundo': 'world',
#     'libro': 'book',
#     'perro': 'dog',
#     'gato': 'cat'
# }

# def traducir(palabra):
#     # Buscar la palabra en el diccionario
#     palabra = palabra.lower()
#     traduccion = traducciones.get(palabra)
    
#     # Si la palabra está en el diccionario, retornar la traducción
#     if traduccion:
#         return traduccion
#     else:
#         # Si la palabra no está en el diccionario, preguntar si desea añadirla
#         respuesta = input(f"La palabra '{palabra}' no está en el diccionario. ¿Deseas añadir una traducción? (s/n): ")
#         if respuesta.lower() == 's':
#             nueva_traduccion = input(f"Ingresa la traducción al inglés para '{palabra}': ")
#             traducciones[palabra] = nueva_traduccion
#             return nueva_traduccion
#         else:
#             return "Palabra no encontrada en el diccionario."

# # Loop para traducir palabras continuamente
# while True:
#     palabra_a_traducir = input("Ingresa la palabra en español para traducir (o 'salir' para terminar): ")
#     if palabra_a_traducir.lower() == 'salir':
#         break
#     resultado = traducir(palabra_a_traducir)
#     print(f"Traducción: {resultado}")


def cargar_traducciones(archivo):
    traducciones = {}
    try:
        with open(archivo, 'r', encoding='utf-8') as file:
            for linea in file:
                partes = linea.strip().split(':')
                if len(partes) == 2:
                    espanol, ingles = partes
                    traducciones[espanol.strip()] = ingles.strip()
    except FileNotFoundError:
        print("Archivo no encontrado, se creará uno nuevo.")
    return traducciones

def guardar_traducciones(traducciones, archivo):
    with open(archivo, 'w', encoding='utf-8') as file:
        for espanol, ingles in traducciones.items():
            file.write(f"{espanol}: {ingles}\n")

def traducir(palabra, traducciones, archivo):
    palabra = palabra.lower()
    traduccion = traducciones.get(palabra)
    
    if traduccion:
        return traduccion
    else:
        respuesta = input(f"La palabra '{palabra}' no está en el diccionario. ¿Deseas añadir una traducción? (s/n): ")
        if respuesta.lower() == 's':
            nueva_traduccion = input(f"Ingresa la traducción al inglés para '{palabra}': ")
            traducciones[palabra] = nueva_traduccion
            guardar_traducciones(traducciones, archivo)
            return nueva_traduccion
        else:
            return "Palabra no encontrada en el diccionario."

# Nombre del archivo de traducciones
archivo_traducciones = 'traducciones.txt'

# Cargar traducciones existentes
traducciones = cargar_traducciones(archivo_traducciones)

# Loop para traducir palabras continuamente
while True:
    palabra_a_traducir = input("Ingresa la palabra en español para traducir (o 'salir' para terminar): ")
    if palabra_a_traducir.lower() == 'salir':
        break
    resultado = traducir(palabra_a_traducir, traducciones, archivo_traducciones)
    print(f"Traducción: {resultado}")

