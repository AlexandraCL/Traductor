def distancia_levenshtein(s1, s2):
    if len(s1) > len(s2):
        s1, s2 = s2, s1

    distancias = range(len(s1) + 1)
    for index2, char2 in enumerate(s2):
        nuevos_distancias = [index2 + 1]
        for index1, char1 in enumerate(s1):
            if char1 == char2:
                nuevos_distancias.append(distancias[index1])
            else:
                nuevos_distancias.append(1 + min((distancias[index1], distancias[index1 + 1], nuevos_distancias[-1])))
        distancias = nuevos_distancias
    return distancias[-1]



def sugerir_palabras(palabra, traducciones, max_distancia=3):
    sugerencias = []
    for palabra_existente in traducciones.keys():
        distancia = distancia_levenshtein(palabra, palabra_existente)
        if distancia <= max_distancia:
            sugerencias.append(palabra_existente)
    return sugerencias


def cargar_traducciones(archivo):
    traducciones = {}
    try:
        with open(archivo, 'r', encoding='utf-8') as file:
            for linea in file:
                partes = linea.strip().split(':')
                if len(partes) == 2:
                    espanol, ingles = partes
                    traducciones[espanol.strip()] = ingles.strip()
    except FileNotFoundError:
        print("Archivo no encontrado, se creará uno nuevo.")
    return traducciones

def guardar_traducciones(traducciones, archivo):
    with open(archivo, 'w', encoding='utf-8') as file:
        for espanol, ingles in traducciones.items():
            file.write(f"{espanol}: {ingles}\n")

def traducir(palabra, traducciones, archivo):
    palabra = palabra.lower()
    traduccion = traducciones.get(palabra)

    if traduccion:
        return traduccion
    else:
        sugerencias = sugerir_palabras(palabra, traducciones)
        if sugerencias:
            sugerencias_str = ', '.join(sugerencias)
            print(f"Palabras sugeridas: {sugerencias_str}")
            respuesta = input("¿Alguna de estas palabras es la que querías? (s/n): ")
            if respuesta.lower() == 's':
                palabra_elegida = input("Escribe la palabra correcta de las sugeridas: ")
                return traducciones.get(palabra_elegida, "No se encontró la traducción.")
        
        respuesta = input(f"La palabra '{palabra}' no está en el diccionario. ¿Deseas añadir una traducción? (s/n): ")
        if respuesta.lower() == 's':
            nueva_traduccion = input(f"Ingresa la traducción al inglés para '{palabra}': ")
            traducciones[palabra] = nueva_traduccion
            guardar_traducciones(traducciones, archivo)
            return nueva_traduccion
        else:
            return "Palabra no encontrada en el diccionario."


archivo_traducciones = 'traducciones.txt'

# Cargar traducciones existentes
traducciones = cargar_traducciones(archivo_traducciones)

# Loop para traducir palabras continuamente
while True:
    palabra_a_traducir = input("Ingresa la palabra en español para traducir (o 'salir' para terminar): ")
    if palabra_a_traducir.lower() == 'salir':
        break
    resultado = traducir(palabra_a_traducir, traducciones, archivo_traducciones)
    print(f"Traducción: {resultado}")



