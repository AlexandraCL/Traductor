
def distancia_levenshtein(s1, s2):
    if len(s1) > len(s2):
        s1, s2 = s2, s1
    distancias = range(len(s1) + 1)
    for index2, char2 in enumerate(s2):
        nuevos_distancias = [index2 + 1]
        for index1, char1 in enumerate(s1):
            if char1 == char2:
                nuevos_distancias.append(distancias[index1])
            else:
                nuevos_distancias.append(1 + min((distancias[index1], distancias[index1 + 1], nuevos_distancias[-1])))
        distancias = nuevos_distancias
    return distancias[-1]

def cargar_traducciones(archivo):
    traducciones = {}
    try:
        with open(archivo, 'r', encoding='utf-8') as file:
            for linea in file:
                partes = linea.strip().split(':')
                if len(partes) == 3:
                    espanol, ingles, contador = partes
                    traducciones[espanol.strip()] = {'traduccion': ingles.strip(), 'contador': int(contador)}
    except FileNotFoundError:
        print("Archivo no encontrado, se creará uno nuevo.")
    return traducciones


def guardar_traducciones(traducciones, archivo):
    with open(archivo, 'w', encoding='utf-8') as file:
        for espanol, data in traducciones.items():
            file.write(f"{espanol}: {data['traduccion']}: {data['contador']}\n")

def sugerir_palabras(palabra, traducciones, max_distancia=3):
    sugerencias = []
    for palabra_existente, data in traducciones.items():
        distancia = distancia_levenshtein(palabra, palabra_existente)
        if distancia <= max_distancia:
            sugerencias.append((palabra_existente, data['contador']))
    sugerencias.sort(key=lambda x: x[1], reverse=True)
    return [s[0] for s in sugerencias]

# def traducir_frase(frase, traducciones, archivo):
#     palabras = frase.lower().split()
#     frase_traducida = []
#     for palabra in palabras:
#         traduccion = traducciones.get(palabra, {}).get('traduccion')
#         if not traduccion:
#             sugerencias = sugerir_palabras(palabra, traducciones)
#             if sugerencias:
#                 sugerencias_str = ', '.join(sugerencias)
#                 print(f"Palabras sugeridas para '{palabra}': {sugerencias_str}")
#                 respuesta = input("¿Alguna de estas palabras es la que querías? (s/n): ")
#                 if respuesta.lower() == 's':
#                     palabra_elegida = input("Escribe la palabra correcta de las sugeridas: ")
#                     if palabra_elegida in traducciones:
#                         traducciones[palabra_elegida]['contador'] += 1
#                         guardar_traducciones(traducciones, archivo)
#                         traduccion = traducciones[palabra_elegida]['traduccion']
#                 if not traduccion:
#                     respuesta = input(f"La palabra '{palabra}' no está en el diccionario. ¿Deseas añadir una traducción? (s/n): ")
#                     if respuesta.lower() == 's':
#                         nueva_traduccion = input(f"Ingresa la traducción al inglés para '{palabra}': ")
#                         traducciones[palabra] = {'traduccion': nueva_traduccion, 'contador': 0}
#                         guardar_traducciones(traducciones, archivo)
#                         traduccion = nueva_traduccion
#                     else:
#                         traduccion = palabra  # Usar palabra original si no se proporciona traducción
#             else:
#                 traduccion = palabra  # Usar palabra original si no hay sugerencias
#         frase_traducida.append(traduccion)
#     return ' '.join(frase_traducida)

def traducir_frase(frase, traducciones, archivo):
    palabras = frase.lower().split()
    frase_traducida = []
    for palabra in palabras:
        traduccion = traducciones.get(palabra, {}).get('traduccion')
        if not traduccion:
            sugerencias = sugerir_palabras(palabra, traducciones)
            if sugerencias:
                sugerencias_str = ', '.join(sugerencias)
                print(f"Palabras sugeridas para '{palabra}': {sugerencias_str}")
                respuesta = input("¿Alguna de estas palabras es la que querías? (s/n): ")
                if respuesta.lower() == 's':
                    palabra_elegida = input("Escribe la palabra correcta de las sugeridas: ")
                    if palabra_elegida in traducciones:
                        traducciones[palabra_elegida]['contador'] += 1
                        guardar_traducciones(traducciones, archivo)
                        traduccion = traducciones[palabra_elegida]['traduccion']
                    else:
                        traduccion = palabra  # Usar palabra original si no se selecciona ninguna
                if not traduccion:
                    respuesta = input(f"La palabra '{palabra}' no está en el diccionario. ¿Deseas añadir una traducción? (s/n): ")
                    if respuesta.lower() == 's':
                        nueva_traduccion = input(f"Ingresa la traducción al inglés para '{palabra}': ")
                        traducciones[palabra] = {'traduccion': nueva_traduccion, 'contador': 0}
                        guardar_traducciones(traducciones, archivo)
                        traduccion = nueva_traduccion
                    else:
                        traduccion = palabra  # Usar palabra original si no se proporciona traducción
            else:
                respuesta = input(f"La palabra '{palabra}' no está en el diccionario y no hay sugerencias. ¿Deseas añadir una traducción? (s/n): ")
                if respuesta.lower() == 's':
                    nueva_traduccion = input(f"Ingresa la traducción al inglés para '{palabra}': ")
                    traducciones[palabra] = {'traduccion': nueva_traduccion, 'contador': 0}
                    guardar_traducciones(traducciones, archivo)
                    traduccion = nueva_traduccion
                else:
                    traduccion = palabra  # Usar palabra original si no se proporciona traducción
        frase_traducida.append(traduccion)
    return ' '.join(frase_traducida)


def menu_principal():
    archivo_traducciones = 'traducciones.txt'
    traducciones = cargar_traducciones(archivo_traducciones)
    while True:
        print("\nMenú Principal")
        print("1. Traducir palabra o frase")
        print("2. Agregar traducción")
        print("3. Salir")
        opcion = input("Selecciona una opción: ")

        if opcion == '1':
            texto_a_traducir = input("Ingresa la palabra o frase en español para traducir: ")
            resultado = traducir_frase(texto_a_traducir, traducciones, archivo_traducciones)
            print(f"Traducción: {resultado}")
        elif opcion == '2':
            palabra = input("Ingresa la palabra en español: ")
            traduccion = input("Ingresa su traducción al inglés: ")
            if palabra not in traducciones:
                traducciones[palabra] = {'traduccion': traduccion, 'contador': 0}
                guardar_traducciones(traducciones, archivo_traducciones)
                print("Traducción añadida con éxito.")
            else:
                print("La palabra ya existe en el diccionario.")
        elif opcion == '3':
            print("Gracias por usar el traductor.")
            break
        else:
            print("Opción no válida, por favor intenta de nuevo.")

if __name__ == "__main__":
    menu_principal()
